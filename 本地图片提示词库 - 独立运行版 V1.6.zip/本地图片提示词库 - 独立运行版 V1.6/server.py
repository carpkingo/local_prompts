from flask import Flask, request, send_from_directory, jsonify
import os, uuid, json, datetime, platform, subprocess
from PIL import Image
app = Flask(__name__)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
IMG_SAVE_DIR = os.path.join(BASE_DIR, "img_lib")
THUMB_DIR = os.path.join(IMG_SAVE_DIR, "thumb")
BACKUP_DIR = os.path.join(BASE_DIR, "backup")
LIBRARY_DB_PATH = os.path.join(BASE_DIR, "library_db.json")
TAG_POOL_DB_PATH = os.path.join(BASE_DIR, "tag_pool.json")
os.makedirs(IMG_SAVE_DIR, exist_ok=True)
os.makedirs(THUMB_DIR, exist_ok=True)
os.makedirs(BACKUP_DIR, exist_ok=True)
ALLOW_EXT = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp"}
MAX_FILE_SIZE = 20 * 1024 * 1024
THUMB_MAX_SIZE = 400
THUMB_QUALITY = 70

def generate_thumbnail(src_path, dest_path):
    """生成缩略图，最大边 THUMB_MAX_SIZE 像素，保存为 JPEG"""
    try:
        with Image.open(src_path) as img:
            img = img.convert("RGB")
            img.thumbnail((THUMB_MAX_SIZE, THUMB_MAX_SIZE), Image.LANCZOS)
            img.save(dest_path, "JPEG", quality=THUMB_QUALITY, optimize=True)
        return True
    except Exception as e:
        print(f"生成缩略图失败 {src_path}: {str(e)}")
        return False

def batch_gen_thumbs():
    """启动时批量补生成已有图片的缩略图"""
    count = 0
    for fname in os.listdir(IMG_SAVE_DIR):
        fpath = os.path.join(IMG_SAVE_DIR, fname)
        if not os.path.isfile(fpath):
            continue
        ext = os.path.splitext(fname)[1].lower()
        if ext not in ALLOW_EXT:
            continue
        thumb_name = os.path.splitext(fname)[0] + ".jpg"
        thumb_path = os.path.join(THUMB_DIR, thumb_name)
        if os.path.exists(thumb_path):
            continue
        if generate_thumbnail(fpath, thumb_path):
            count += 1
    if count > 0:
        print(f"[启动] 补生成 {count} 张缩略图")

def load_json_db(file_path, default_data):
    if not os.path.exists(file_path):
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(default_data, f, ensure_ascii=False, indent=2)
        return default_data
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"读取文件 {file_path} 失败: {str(e)}")
        return default_data

def save_json_db(file_path, data):
    try:
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True, "success"
    except Exception as e:
        print(f"写入文件 {file_path} 失败: {str(e)}")
        return False, str(e)

@app.route("/")
def index():
    return send_from_directory(BASE_DIR, "index.html")

@app.route("/style.css")
def serve_css():
    return send_from_directory(BASE_DIR, "style.css")

@app.route("/main.js")
def serve_js():
    return send_from_directory(BASE_DIR, "main.js")

@app.route("/img_lib/<filename>")
def serve_img(filename):
    return send_from_directory(IMG_SAVE_DIR, filename)

@app.route("/img_lib/thumb/<filename>")
def serve_thumb(filename):
    thumb_path = os.path.join(THUMB_DIR, filename)
    if os.path.exists(thumb_path):
        return send_from_directory(THUMB_DIR, filename)
    # 缩略图不存在时回退到原图
    orig_name = os.path.splitext(filename)[0]
    for ext in ALLOW_EXT:
        orig_path = os.path.join(IMG_SAVE_DIR, orig_name + ext)
        if os.path.exists(orig_path):
            return send_from_directory(IMG_SAVE_DIR, orig_name + ext)
    return send_from_directory(THUMB_DIR, filename)

@app.route("/db-load", methods=["GET"])
def db_load():
    library = load_json_db(LIBRARY_DB_PATH, [])
    tag_pool = load_json_db(TAG_POOL_DB_PATH, [])
    return jsonify({
        "code": 200,
        "library": library,
        "tag_pool": tag_pool
    })

@app.route("/db-save-library", methods=["POST"])
def db_save_library():
    try:
        data = request.get_json()
        lib_data = data.get("library", [])
        ok, msg = save_json_db(LIBRARY_DB_PATH, lib_data)
        if ok:
            return jsonify({"code": 200, "msg": "图库数据已持久化到磁盘"})
        else:
            return jsonify({"code": 500, "msg": f"写入图库数据库失败: {msg}"})
    except Exception as e:
        return jsonify({"code": 500, "msg": str(e)})

@app.route("/db-save-tags", methods=["POST"])
def db_save_tags():
    try:
        data = request.get_json()
        tags_data = data.get("tags", [])
        ok, msg = save_json_db(TAG_POOL_DB_PATH, tags_data)
        if ok:
            return jsonify({"code": 200, "msg": "标签池已持久化到磁盘"})
        else:
            return jsonify({"code": 500, "msg": f"写入标签数据库失败: {msg}"})
    except Exception as e:
        return jsonify({"code": 500, "msg": str(e)})

@app.route("/upload-img", methods=["POST"])
def upload_img():
    try:
        if "img" not in request.files:
            return {"code": 400, "msg": "未检测到图片文件"}
        file = request.files["img"]
        if file.filename.strip() == "":
            return {"code": 400, "msg": "文件名为空"}
        file_data = file.read()
        if len(file_data) > MAX_FILE_SIZE:
            return {"code": 400, "msg": "图片不能超过20MB"}
        file.stream.seek(0)
        ext = os.path.splitext(file.filename)[1].lower()
        if ext not in ALLOW_EXT:
            return {"code": 400, "msg": "仅支持 jpg/jpeg/png/gif/webp/bmp"}
        time_str = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        rand_str = str(uuid.uuid4())[:6]
        unique_name = f"{time_str}_{rand_str}{ext}"
        save_path = os.path.join(IMG_SAVE_DIR, unique_name)
        file.save(save_path)
        # 同步生成缩略图
        thumb_name = f"{time_str}_{rand_str}.jpg"
        thumb_path = os.path.join(THUMB_DIR, thumb_name)
        generate_thumbnail(save_path, thumb_path)
        return {"code": 200, "path": f"img_lib/{unique_name}"}
    except Exception as e:
        return {"code": 500, "msg": f"保存失败：{str(e)}"}

@app.route("/delete-img", methods=["POST"])
def delete_img():
    try:
        data = request.get_json()
        img_path = data.get("imgPath", "")
        if not img_path.startswith("img_lib/"):
            return jsonify({"code": 400, "msg": "非法图片路径"})
        filename = img_path.replace("img_lib/", "")
        full_path = os.path.join(IMG_SAVE_DIR, filename)
        if os.path.isfile(full_path):
            os.remove(full_path)
        # 同步删除缩略图
        thumb_name = os.path.splitext(filename)[0] + ".jpg"
        thumb_path = os.path.join(THUMB_DIR, thumb_name)
        if os.path.isfile(thumb_path):
            os.remove(thumb_path)
        if os.path.isfile(full_path):
            return jsonify({"code": 200, "msg": "图片文件已同步删除"})
        else:
            return jsonify({"code": 200, "msg": "图片文件不存在，仅删除记录"})
    except Exception as e:
        return jsonify({"code": 500, "msg": f"删除文件失败：{str(e)}"})

@app.route("/clear-all-img", methods=["POST"])
def clear_all_img():
    try:
        for fname in os.listdir(IMG_SAVE_DIR):
            fpath = os.path.join(IMG_SAVE_DIR, fname)
            if os.path.isfile(fpath):
                os.remove(fpath)
        # 同步清空缩略图
        for fname in os.listdir(THUMB_DIR):
            fpath = os.path.join(THUMB_DIR, fname)
            if os.path.isfile(fpath):
                os.remove(fpath)
        return {"code": 200, "msg": "图片文件夹已清空"}
    except Exception as e:
        return {"code": 500, "msg": str(e)}

@app.route("/export-db", methods=["POST"])
def export_db():
    try:
        library_data = load_json_db(LIBRARY_DB_PATH, [])
        time_str = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_filename = f"图库备份_{time_str}.json"
        backup_full_path = os.path.join(BACKUP_DIR, backup_filename)
        with open(backup_full_path, "w", encoding="utf-8") as f:
            json.dump(library_data, f, ensure_ascii=False, indent=2)
        return jsonify({
            "code": 200,
            "msg": f"备份成功，文件已保存至项目backup文件夹，文件名：{backup_filename}",
            "file_path": backup_full_path
        })
    except Exception as e:
        return jsonify({"code": 500, "msg": f"备份失败：{str(e)}"})

@app.route("/open-img-folder", methods=["POST"])
def open_img_folder():
    try:
        sys = platform.system()
        if sys == "Windows":
            subprocess.Popen(["explorer", IMG_SAVE_DIR])
        elif sys == "Darwin":
            subprocess.Popen(["open", IMG_SAVE_DIR])
        else:
            subprocess.Popen(["xdg-open", IMG_SAVE_DIR])
        return jsonify({"code": 200, "msg": "已打开图片存储文件夹 img_lib"})
    except Exception as e:
        return jsonify({"code": 500, "msg": f"打开文件夹失败：{str(e)}"})

if __name__ == "__main__":
    batch_gen_thumbs()
    app.run(host="0.0.0.0", port=8000, debug=True)
