// 全局轻提示：自动消失，success/error两种样式
function toast(msg, type="success"){
    const div = document.createElement("div");
    div.className = `toast-box toast-${type}`;
    div.innerText = msg;
    document.body.appendChild(div);
    // 3秒后移除
    setTimeout(()=>div.remove(), 3000);
}
document.addEventListener('dragstart', e => {
    if (e.target.tagName === 'IMG') {
        e.preventDefault();
        e.stopPropagation();
    }
}, true);
const STORAGE_KEY = "prompt_lib_path_db";
const TAG_POOL_KEY = "prompt_lib_tag_pool";
const UPLOAD_API = "/upload-img";
const DB_LOAD_API = "/db-load";
const SAVE_LIB_API = "/db-save-library";
const SAVE_TAG_API = "/db-save-tags";
let library = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
let tagPool = JSON.parse(localStorage.getItem(TAG_POOL_KEY) || "[]");
let currentViewId = null;
let selectedFile = null;
let savedImgPath = "";
let batchSelectedTags = [];
let filterSelectedTags = [];
let scale = 1;
let translateX = 0;
let translateY = 0;
let isDragging = false;
let startX = 0;
let startY = 0;
let modalOriginData = { tags: "", pos: "", nsfw: false };
let isPosEditMode = false;
let batchModeOpen = false;
let batchSelectIds = [];
let sortMode = 0;
// 替换图片全局变量
let replaceNewFile = null;
let oldModalImgPath = "";
// 懒加载观察器
let lazyObserver = null;
// 原图路径转缩略图路径：img_lib/xxx.jpg -> img_lib/thumb/xxx.jpg
function getThumbPath(imgPath) {
    if (!imgPath) return "";
    const parts = imgPath.split("/");
    const filename = parts[parts.length - 1];
    const nameWithoutExt = filename.replace(/\.[^.]+$/, "");
    return `img_lib/thumb/${nameWithoutExt}.jpg`;
}

async function syncLibraryToDisk() {
    try {
        const res = await fetch(SAVE_LIB_API, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ library: library })
        });
        const ret = await res.json();
        if (ret.code !== 200) throw new Error(ret.msg);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(library));
        return true;
    } catch (err) {
        toast("图库持久化保存失败：" + err.message);
        return false;
    }
}
async function syncTagPoolToDisk() {
    try {
        const res = await fetch(SAVE_TAG_API, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ tags: tagPool })
        });
        const ret = await res.json();
        if (ret.code !== 200) throw new Error(ret.msg);
        localStorage.setItem(TAG_POOL_KEY, JSON.stringify(tagPool));
        return true;
    } catch (err) {
        toast("标签池持久化保存失败：" + err.message);
        return false;
    }
}
function fixCopyCountForAll() {
    let changed = false;
    library.forEach(item => {
        if (item.copyCount === undefined || typeof item.copyCount !== "number") {
            item.copyCount = 0;
            changed = true;
        }
    });
    if (changed) syncLibraryToDisk();
}
async function loadDiskDatabase() {
    if (location.protocol === "file:") {
        console.warn("本地文件模式无法读取后端数据库，使用localStorage兜底");
        return;
    }
    try {
        const res = await fetch("/db-load");
        const data = await res.json();
        if (data.code === 200) {
            library = data.library;
            tagPool = data.tag_pool;
            localStorage.setItem("promptLibData", JSON.stringify(library));
            localStorage.setItem("tagPoolData", JSON.stringify(tagPool));
        }
    } catch (err) {
        toast("读取本地数据库失败，当前使用浏览器缓存数据：" + err.message);
    }
}
document.addEventListener('DOMContentLoaded', async function () {
    const dropZone = document.getElementById("dropZone");
    const fileSel = document.getElementById("fileSel");
    const imgPreview = document.getElementById("imgPreview");
    const previewPlaceholder = document.querySelector(".preview-placeholder");
    const inpTags = document.getElementById("inpTags");
    const tagSuggest = document.getElementById("tagSuggest");
    const nsfwToggle = document.getElementById("nsfwToggle");
    const inpPos = document.getElementById("inpPos");
    const btnAdd = document.getElementById("btnAdd");
    const btnClearInput = document.getElementById("btnClearInput");
    const gallery = document.getElementById("gallery");
    const searchInput = document.getElementById("searchInput");
    const toggleShowNsfw = document.getElementById("toggleShowNsfw");
    const modeTip = document.getElementById("modeTip");
    const tagHistoryBox = document.getElementById("tagHistoryBox");
    const tagFilterBox = document.getElementById("tagFilterBox");
    const clearAllTagFilter = document.getElementById("clearAllTagFilter");
    const modal = document.getElementById("modal");
    const modalLeft = document.getElementById("modalLeft");
    const modalImg = document.getElementById("modalImg");
    const modalTags = document.getElementById("modalTags");
    const modalCopyCount = document.getElementById("modalCopyCount");
    const modalContent = document.getElementById("modalContent");
    const editPosTextarea = document.getElementById("editPosTextarea");
    const togglePosEdit = document.getElementById("togglePosEdit");
    const editTagsInput = document.getElementById("editTagsInput");
    const editNsfwToggle = document.getElementById("editNsfwToggle");
    const btnSaveEditTags = document.getElementById("btnSaveEditTags");
    const btnCopyAll = document.getElementById("btnCopyAll");
    const btnDeleteItem = document.getElementById("btnDeleteItem");
    const closeModalBtn = document.getElementById("closeModalBtn");
    const zoomHint = document.getElementById("zoomHint");
    const batchTagModal = document.getElementById("batchTagModal");
    const batchTagList = document.getElementById("batchTagList");
    const btnBatchTagManage = document.getElementById("btnBatchTagManage");
    const batchDelTagBtn = document.getElementById("batchDelTagBtn");
    const closeBatchTagModal = document.getElementById("closeBatchTagModal");
    const btnExport = document.getElementById("btnExport");
    const btnImport = document.getElementById("btnImport");
    const importFile = document.getElementById("importFile");
    const btnClearAllData = document.getElementById("btnClearAllData");
    const clearConfirmModal = document.getElementById("clearConfirmModal");
    const cancelClearData = document.getElementById("cancelClearData");
    const confirmClearData = document.getElementById("confirmClearData");
    const importMergeMode = document.getElementById("importMergeMode");
    const toggleBatchMode = document.getElementById("toggleBatchMode");
    const btnBatchDelete = document.getElementById("btnBatchDelete");
    const batchTipRow = document.getElementById("batchTipRow");
    const batchCountTip = document.getElementById("batchCountTip");
    const selectAllBtn = document.getElementById("selectAllBtn");
    const clearSelectBtn = document.getElementById("clearSelectBtn");
    const batchDelConfirmModal = document.getElementById("batchDelConfirmModal");
    const batchDelTipText = document.getElementById("batchDelTipText");
    const batchDelFileTip = document.getElementById("batchDelFileTip");
    const cancelBatchDel = document.getElementById("cancelBatchDel");
    const confirmBatchDel = document.getElementById("confirmBatchDel");
    const sortSelect = document.getElementById("sortSelect");
    const syncDeleteImgSwitch = document.getElementById("syncDeleteImgSwitch");
    const btnOpenImgFolder = document.getElementById("btnOpenImgFolder");
    // 替换图片DOM
    const toggleReplaceImg = document.getElementById("toggleReplaceImg");
    const replaceImgInput = document.getElementById("replaceImgInput");
    const replaceImgPreviewWrap = document.getElementById("replaceImgPreviewWrap");
    const replaceImgPreview = document.getElementById("replaceImgPreview");
    // 返回顶部按钮DOM
    const backToTopBtn = document.getElementById("backToTop");
    // 更新日志弹窗DOM
    const openChangelogBtn = document.getElementById("openChangelogBtn");
    const changelogModal = document.getElementById("changelogModal");
    const closeChangelogBtn = document.getElementById("closeChangelogBtn");
    const closeChangelogModalBtn = document.getElementById("closeChangelogModalBtn");

// ========== 更新日志弹窗逻辑 ==========
function closeChangelogModal() {
    changelogModal.style.display = "none";
}
openChangelogBtn.onclick = () => {
    changelogModal.style.display = "flex";
};
closeChangelogBtn.onclick = closeChangelogModal;
closeChangelogModalBtn.onclick = closeChangelogModal;
// 点击弹窗黑色遮罩关闭
changelogModal.onclick = (e) => {
    if (e.target === changelogModal) closeChangelogModal();
};
    // 初始化图片懒加载观察器：进入视口前300px开始加载缩略图
    lazyObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                const src = img.getAttribute("data-src");
                if (src) {
                    img.src = src;
                    img.removeAttribute("data-src");
                }
                lazyObserver.unobserve(img);
            }
        });
    }, { rootMargin: "300px 0px", threshold: 0.01 });
    if (location.protocol === "file:") {
        modeTip.innerText = "⚠️ 直接双击HTML打开，无法自动复制外部图片、无法读取本地数据库，请启动python服务访问 http://127.0.0.1:8000";
        btnAdd.disabled = true;
        btnAdd.style.opacity = 0.4;
    } else {
        modeTip.innerText = "✅ HTTP服务运行中，图库数据持久化保存在项目 library_db.json";
    }

    // ========== 返回顶部逻辑 ==========
    // 滚动监听，滚动超过一屏高度显示按钮
    function checkScrollShowBtn(){
        const scrollY = window.scrollY;
        const screenHeight = window.innerHeight;
        if(scrollY >= screenHeight){
            backToTopBtn.classList.add("show");
        }else{
            backToTopBtn.classList.remove("show");
        }
    }
    // 平滑回到顶部
    backToTopBtn.onclick = () => {
        window.scrollTo({
            top:0,
            behavior:"smooth"
        });
    };
    window.addEventListener("scroll", checkScrollShowBtn);
    // 初始化判断一次
    checkScrollShowBtn();

    btnOpenImgFolder.onclick = async () => {
        try {
            const res = await fetch("/open-img-folder", { method: "POST" });
            const ret = await res.json();
            if (ret.code === 200) {
                const tip = document.createElement("div");
                tip.style = "position:fixed;top:20px;left:50%;transform:translateX(-50%);background:#227744;color:#fff;padding:10px 20px;border-radius:6px;z-index:9999;";
                tip.innerText = ret.msg;
                document.body.appendChild(tip);
                setTimeout(() => tip.remove(), 2500);
            } else {
                toast("打开失败：" + ret.msg);
            }
        } catch (err) {
            toast("请求异常：" + err.message + "\n请确认服务正常运行");
        }
    };
    toggleShowNsfw.onchange = () => {
        renderTagFilter();
        renderGallery();
    };
    sortSelect.onchange = () => {
        sortMode = Number(sortSelect.value);
        renderGallery();
    };
    toggleBatchMode.onchange = () => {
        batchModeOpen = toggleBatchMode.checked;
        batchSelectIds = [];
        updateBatchTip();
        renderGallery();
    };
    selectAllBtn.onclick = () => {
        const visibleIds = getFilteredList().map(item => item.id);
        batchSelectIds = [...visibleIds];
        updateBatchTip();
        renderGallery();
    };
    clearSelectBtn.onclick = () => {
        batchSelectIds = [];
        updateBatchTip();
        renderGallery();
    };
    function updateBatchTip() {
        const count = batchSelectIds.length;
        batchCountTip.innerText = `已选中：${count} 张`;
        btnBatchDelete.disabled = count === 0;
        batchTipRow.style.display = batchModeOpen ? "flex" : "none";
    }
    function getFilteredList() {
        const kw = searchInput.value.toLowerCase();
        const showNSFW = toggleShowNsfw.checked;
        const onlyNSFW = filterSelectedTags.includes("__nsfw_only");
        const filterTags = filterSelectedTags.filter(t => t !== "__nsfw_only");
        return library.filter(item => {
            if (item.nsfw && !showNSFW) return false;
            if (onlyNSFW && !item.nsfw) return false;
            if (filterTags.length > 0) {
                const set = new Set(item.tags);
                for (const t of filterTags) if (!set.has(t)) return false;
            }
            if (!kw) return true;
            const tagStr = item.tags.join(" ").toLowerCase();
            return item.pos.toLowerCase().includes(kw) || tagStr.includes(kw);
        });
    }
    btnBatchDelete.onclick = () => {
        const cnt = batchSelectIds.length;
        batchDelTipText.innerText = `确认永久删除选中的 ${cnt} 条图库记录？复制计数一并清除`;
        if (syncDeleteImgSwitch.checked) {
            batchDelFileTip.innerText = "同步删除img_lib内对应的图片文件，无法恢复";
        } else {
            batchDelFileTip.innerText = "仅删除记录，本地img_lib图片文件保留";
        }
        batchDelConfirmModal.style.display = "flex";
    };
    cancelBatchDel.onclick = () => batchDelConfirmModal.style.display = "none";
    batchDelConfirmModal.onclick = (e) => {
        if (e.target === batchDelConfirmModal) batchDelConfirmModal.style.display = "none";
    };
    confirmBatchDel.onclick = async () => {
        const delItems = library.filter(item => batchSelectIds.includes(item.id));
        if (syncDeleteImgSwitch.checked) {
            for (const item of delItems) {
                try {
                    await fetch("/delete-img", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ imgPath: item.imgPath })
                    });
                } catch (err) {
                    console.warn("删除图片失败", item.imgPath, err);
                }
            }
        }
        library = library.filter(item => !batchSelectIds.includes(item.id));
        await syncLibraryToDisk();
        batchSelectIds = [];
        batchDelConfirmModal.style.display = "none";
        updateBatchTip();
        renderGallery();
        const tip = document.createElement("div");
        tip.style = "position:fixed;top:20px;left:50%;transform:translateX(-50%);background:#227744;color:#fff;padding:10px 20px;border-radius:6px;z-index:9999;";
        tip.innerText = syncDeleteImgSwitch.checked ? "批量删除完成，对应原图已清理，数据已持久化" : "批量删除完成，仅移除记录，原图保留，数据已持久化";
        document.body.appendChild(tip);
        setTimeout(() => tip.remove(), 2500);
    };
    nsfwToggle.onclick = () => nsfwToggle.classList.toggle("active");
    editNsfwToggle.onclick = () => {
        editNsfwToggle.classList.toggle("active");
        checkModalModified();
    };
    togglePosEdit.onclick = () => {
        isPosEditMode = !isPosEditMode;
        if (isPosEditMode) {
            editPosTextarea.value = modalContent.innerText;
            modalContent.style.display = "none";
            editPosTextarea.style.display = "block";
            togglePosEdit.innerText = "预览提示词";
        } else {
            modalContent.innerText = editPosTextarea.value;
            modalContent.style.display = "block";
            editPosTextarea.style.display = "none";
            togglePosEdit.innerText = "编辑提示词";
        }
        checkModalModified();
    };
    // 替换图片绑定
    toggleReplaceImg.onclick = () => replaceImgInput.click();
    replaceImgInput.addEventListener("change", () => {
        const file = replaceImgInput.files[0];
        if (!file) {
            replaceNewFile = null;
            replaceImgPreviewWrap.style.display = "none";
            checkModalModified();
            return;
        }
        replaceNewFile = file;
        const reader = new FileReader();
        reader.onload = e => {
            replaceImgPreview.src = e.target.result;
            replaceImgPreviewWrap.style.display = "block";
        };
        reader.readAsDataURL(file);
        checkModalModified();
    });

    editTagsInput.addEventListener("input", checkModalModified);
    modalContent.addEventListener("input", checkModalModified);
    editPosTextarea.addEventListener("input", checkModalModified);
    function checkModalModified() {
        const currentTags = editTagsInput.value.trim();
        let currentPos = isPosEditMode ? editPosTextarea.value.trim() : modalContent.innerText.trim();
        const currentNsfw = editNsfwToggle.classList.contains("active");
        const changed = currentTags !== modalOriginData.tags
            || currentPos !== modalOriginData.pos
            || currentNsfw !== modalOriginData.nsfw
            || replaceNewFile !== null;
        btnSaveEditTags.disabled = !changed;
    }
    function renderTagHistory() {
        tagHistoryBox.innerHTML = "";
        tagPool.forEach(tag => {
            const btn = document.createElement("button");
            btn.className = "tag-history-btn";
            btn.innerText = tag;
            btn.onclick = () => {
                let val = inpTags.value.trim();
                if (val && !val.endsWith(",")) val += ",";
                inpTags.value = val + tag + ",";
                inpTags.focus();
            };
            tagHistoryBox.appendChild(btn);
        });
    }
    function renderTagFilter() {
        tagFilterBox.innerHTML = "";
        const showNSFW = toggleShowNsfw.checked;
        if (showNSFW) {
            const nsfwBtn = document.createElement("button");
            nsfwBtn.className = "tag-history-btn";
            nsfwBtn.innerText = "NSFW";
            if (filterSelectedTags.includes("__nsfw_only")) nsfwBtn.classList.add("active");
            nsfwBtn.onclick = () => {
                if (filterSelectedTags.includes("__nsfw_only")) {
                    filterSelectedTags = filterSelectedTags.filter(t => t !== "__nsfw_only");
                } else {
                    filterSelectedTags.push("__nsfw_only");
                }
                renderTagFilter();
                renderGallery();
            };
            tagFilterBox.appendChild(nsfwBtn);
        }
        tagPool.forEach(tag => {
            const btn = document.createElement("button");
            btn.className = "tag-history-btn";
            if (filterSelectedTags.includes(tag)) btn.classList.add("active");
            btn.innerText = tag;
            btn.onclick = () => {
                if (filterSelectedTags.includes(tag)) {
                    filterSelectedTags = filterSelectedTags.filter(t => t !== tag);
                } else {
                    filterSelectedTags.push(tag);
                }
                renderTagFilter();
                renderGallery();
            };
            tagFilterBox.appendChild(btn);
        });
    }
    clearAllTagFilter.onclick = () => {
        filterSelectedTags = [];
        renderTagFilter();
        renderGallery();
    };
    function renderBatchTagList() {
        batchTagList.innerHTML = "";
        batchSelectedTags = [];
        tagPool.forEach(tag => {
            const wrap = document.createElement("label");
            wrap.className = "tag-check-item";
            const ck = document.createElement("input");
            ck.type = "checkbox";
            ck.value = tag;
            ck.onchange = () => {
                if (ck.checked) batchSelectedTags.push(tag);
                else batchSelectedTags = batchSelectedTags.filter(t => t !== tag);
            };
            wrap.appendChild(ck);
            wrap.append(document.createTextNode(tag));
            batchTagList.appendChild(wrap);
        });
    }
    btnBatchTagManage.onclick = () => {
        renderBatchTagList();
        batchTagModal.style.display = "flex";
    };
    closeBatchTagModal.onclick = () => batchTagModal.style.display = "none";
    batchDelTagBtn.onclick = async () => {
        if (batchSelectedTags.length === 0) return toast("请勾选标签");
        if (!confirm(`删除${batchSelectedTags.length}个历史标签？不影响图库`)) return;
        tagPool = tagPool.filter(t => !batchSelectedTags.includes(t));
        await syncTagPoolToDisk();
        renderTagHistory();
        renderTagFilter();
        renderBatchTagList();
        toast("删除完成，标签池已持久化更新");
    };
    dropZone.addEventListener("dragover", e => { e.preventDefault(); dropZone.classList.add("active"); });
    dropZone.addEventListener("dragleave", e => { e.preventDefault(); dropZone.classList.remove("active"); });
    dropZone.addEventListener("drop", e => {
        e.preventDefault();
        dropZone.classList.remove("active");
        const f = e.dataTransfer.files[0];
        if (f && f.type.startsWith("image/")) handleFileSelect(f);
    });
    fileSel.addEventListener("change", () => {
        const f = fileSel.files[0];
        if (f) handleFileSelect(f);
    });
    function handleFileSelect(file) {
        savedImgPath = "";
        selectedFile = file;
        const r = new FileReader();
        r.onload = ev => {
            imgPreview.src = ev.target.result;
            imgPreview.style.display = "block";
            previewPlaceholder.style.display = "none";
        };
        r.readAsDataURL(file);
    }
    async function uploadImage(file) {
        const fd = new FormData();
        fd.append("img", file);
        try {
            const res = await fetch(UPLOAD_API, {
                method: "POST",
                body: fd
            });
            if (!res.ok) throw new Error(`服务器返回错误码 ${res.status}`);
            const json = await res.json();
            if (json.code !== 200) throw new Error(json.msg || "上传失败");
            return json.path;
        } catch (err) {
            if (location.protocol === "file:") {
                throw new Error("禁止直接打开HTML！请运行server.py，访问 http://127.0.0.1:8000");
            }
            throw new Error(err.message);
        }
    }
    async function updateTagPool(tags) {
        let validTags = tags.filter(t => t.trim() !== "");
        let changed = false;
        validTags.forEach(t => {
            if (!tagPool.includes(t)) {
                tagPool.push(t);
                changed = true;
            }
        });
        if (changed) {
            await syncTagPoolToDisk();
            renderTagHistory();
            renderTagFilter();
        }
    }
    inpTags.addEventListener("input", () => {
        const val = inpTags.value;
        const comma = val.lastIndexOf(",");
        const kw = comma > -1 ? val.slice(comma + 1).trim() : val.trim();
        if (!kw) {
            tagSuggest.style.display = "none";
            return;
        }
        const match = tagPool.filter(t => t.toLowerCase().includes(kw.toLowerCase())).slice(0, 8);
        if (match.length === 0) {
            tagSuggest.style.display = "none";
            return;
        }
        tagSuggest.innerHTML = "";
        match.forEach(t => {
            const div = document.createElement("div");
            div.className = "tag-suggest-item";
            div.innerText = t;
            div.onclick = () => {
                if (comma === -1) {
                    inpTags.value = t + ",";
                } else {
                    inpTags.value = val.slice(0, comma + 1) + t + ",";
                }
                tagSuggest.style.display = "none";
                inpTags.focus();
            };
            tagSuggest.appendChild(div);
        });
        tagSuggest.style.display = "block";
    });
    document.addEventListener("click", ev => {
        if (!inpTags.contains(ev.target) && !tagSuggest.contains(ev.target)) {
            tagSuggest.style.display = "none";
        }
    });
    btnAdd.onclick = async () => {
        if (!selectedFile) return toast("请选择图片");
        if (btnAdd.disabled) return;
        try {
            btnAdd.disabled = true;
            btnAdd.innerText = "上传中...";
            savedImgPath = await uploadImage(selectedFile);
            const rawTags = inpTags.value.split(",").map(s => s.trim());
            const tags = rawTags.filter(t => t.length > 0);
            await updateTagPool(tags);
            library.push({
                id: Date.now().toString(),
                tags: tags,
                nsfw: nsfwToggle.classList.contains("active"),
                pos: inpPos.value.trim(),
                imgPath: savedImgPath,
                copyCount: 0
            });
            await syncLibraryToDisk();
            renderGallery();
            clearForm();
            toast("图片入库成功，数据已保存到本地磁盘！");
        } catch (err) {
            toast("错误：" + err.message);
        } finally {
            btnAdd.disabled = false;
            btnAdd.innerText = "保存入库";
        }
    };
    function clearForm() {
        selectedFile = null;
        savedImgPath = "";
        fileSel.value = "";
        imgPreview.style.display = "none";
        previewPlaceholder.style.display = "block";
        inpTags.value = "";
        tagSuggest.style.display = "none";
        nsfwToggle.classList.remove("active");
        inpPos.value = "";
    }
    btnClearInput.onclick = clearForm;
    function renderGallery() {
        gallery.innerHTML = "";
        let list = getFilteredList();
        if (sortMode === 0) {
            list.sort((a, b) => Number(b.id) - Number(a.id));
        } else if (sortMode === 1) {
            list.sort((a, b) => Number(a.id) - Number(b.id));
        } else if (sortMode === 2) {
            list.sort((a, b) => b.copyCount - a.copyCount);
        }
        list.forEach(item => {
            const card = document.createElement("div");
            card.className = "gallery-item";
            if (batchSelectIds.includes(item.id)) card.classList.add("selected");
            let tagHtml = item.tags.map(t => `<span style="margin:0 3px;">${escapeHtml(t)}</span>`).join("");
            if (item.nsfw) tagHtml += `<span class="nsfw-tag">nsfw</span>`;
            tagHtml += `<span class="copy-count-tag">复制:${item.copyCount}次</span>`;
            const checkShow = batchModeOpen ? "display:block" : "display:none";
            card.innerHTML = `
                <input type="checkbox" class="gallery-check" data-id="${item.id}" style="${checkShow}">
                <img data-src="${getThumbPath(item.imgPath)}" class="lazy-img" draggable="false" onerror="this.replaceWith(document.createElement('div')).className='lost-img';this.previousSibling.remove();this.nextSibling.remove();">
                <div class="tag-area">${tagHtml}</div>
            `;
            const ck = card.querySelector(".gallery-check");
            ck.checked = batchSelectIds.includes(item.id);
            card.onclick = (e) => {
                e.stopPropagation();
                if (batchModeOpen) {
                    const id = item.id;
                    if (batchSelectIds.includes(id)) {
                        batchSelectIds = batchSelectIds.filter(i => i !== id);
                    } else {
                        batchSelectIds.push(id);
                    }
                    updateBatchTip();
                    renderGallery();
                } else {
                    openDetailModal(item.id);
                }
            };
            const imgEl = card.querySelector("img");
            if (lazyObserver && imgEl) lazyObserver.observe(imgEl);
            gallery.appendChild(card);
        });
        updateBatchTip();
    }
    function openDetailModal(id) {
        const item = library.find(x => x.id === id);
        if (!item) return;
        currentViewId = id;
        scale = 1; translateX = 0; translateY = 0;
        updateTransform();
        modalImg.src = item.imgPath;
        modalImg.onerror = function () {
            const wrap = this.parentElement;
            this.remove();
            const lost = document.createElement("div");
            lost.className = "lost-img";
            lost.innerText = "图片丢失";
            wrap.appendChild(lost);
        };
        modalOriginData = {
            tags: item.tags.join(","),
            pos: item.pos,
            nsfw: item.nsfw
        };
        isPosEditMode = false;
        modalContent.style.display = "block";
        editPosTextarea.style.display = "none";
        togglePosEdit.innerText = "编辑提示词";
        if (item.nsfw) editNsfwToggle.classList.add("active");
        else editNsfwToggle.classList.remove("active");
        modalCopyCount.innerText = item.copyCount;
        modalTags.innerHTML = item.tags.map(t => `<span style="margin:0 4px;color:#aaa;">${escapeHtml(t)}</span>`).join("")
            + (item.nsfw ? "<span class='nsfw-tag'> nsfw</span>" : "");
        editTagsInput.value = modalOriginData.tags;
        modalContent.innerText = modalOriginData.pos;
        editPosTextarea.value = modalOriginData.pos;
        btnSaveEditTags.disabled = true;
        modal.style.display = "flex";
        zoomHint.style.opacity = 1;
        setTimeout(() => zoomHint.style.opacity = 0, 2500);
        // 重置替换图片
        replaceNewFile = null;
        replaceImgInput.value = "";
        replaceImgPreviewWrap.style.display = "none";
        oldModalImgPath = item.imgPath;
    }
    function updateTransform() {
        modalImg.style.transform = `translate(${translateX}px, ${translateY}px) scale(${scale})`;
    }
    modalLeft.addEventListener("wheel", e => {
        e.preventDefault();
        const d = e.deltaY > 0 ? -0.1 : 0.1;
        scale = Math.max(1, Math.min(5, scale + d));
        updateTransform();
    });
modalLeft.addEventListener("mousedown", e => {
    e.preventDefault();
    e.stopPropagation();
    document.body.style.userSelect = "none";
    if (scale === 1) return;
    isDragging = true;
    startX = e.clientX - translateX;
    startY = e.clientY - translateY;
});
    window.addEventListener("mousemove", e => {
        if (!isDragging) return;
        translateX = e.clientX - startX;
        translateY = e.clientY - startY;
        updateTransform();
    });
    window.addEventListener("mouseup", () => {
    isDragging = false;
    document.body.style.userSelect = "";
});
    btnCopyAll.onclick = async (e) => {
        e.stopPropagation();
        const item = library.find(x => x.id === currentViewId);
        if (!item) return;
        await navigator.clipboard.writeText(item.pos);
        item.copyCount += 1;
        await syncLibraryToDisk();
        modalCopyCount.innerText = item.copyCount;
        renderGallery();
        const tip = document.createElement("div");
        tip.style = "position:fixed;top:20px;left:50%;transform:translateX(-50%);background:#227744;color:#fff;padding:8px 16px;border-radius:6px;z-index:9999;";
        tip.innerText = "提示词已复制，复制次数+1，数据已保存";
        document.body.appendChild(tip);
        setTimeout(() => tip.remove(), 2000);
    };
    btnDeleteItem.onclick = async (e) => {
        e.stopPropagation();
        const item = library.find(x => x.id === currentViewId);
        if (!item) return;
        const syncDel = syncDeleteImgSwitch.checked;
        const confirmText = syncDel
            ? "确认删除本条记录？本地img_lib内对应图片文件会同步删除，无法恢复！"
            : "确认仅删除图库记录？本地图片文件会保留在img_lib文件夹";
        if (!confirm(confirmText)) return;
        if (syncDel) {
            try {
                await fetch("/delete-img", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ imgPath: item.imgPath })
                });
            } catch (err) {
                toast("图片文件删除异常：" + err.message);
            }
        }
        library = library.filter(x => x.id !== currentViewId);
        await syncLibraryToDisk();
        renderGallery();
        modal.style.display = "none";
        currentViewId = null;
        const tip = document.createElement("div");
        tip.style = "position:fixed;top:20px;left:50%;transform:translateX(-50%);background:#227744;color:#fff;padding:8px 16px;border-radius:6px;z-index:9999;";
        tip.innerText = syncDel ? "记录+原图删除完成，磁盘数据已更新" : "仅删除记录，原图保留，磁盘数据已更新";
        document.body.appendChild(tip);
        setTimeout(() => tip.remove(), 2000);
    };
    btnSaveEditTags.onclick = async (e) => {
        e.stopPropagation();
        const item = library.find(x => x.id === currentViewId);
        if (!item) return;
        item.nsfw = editNsfwToggle.classList.contains("active");
        const newTags = editTagsInput.value.split(",").map(s => s.trim()).filter(t => t.length > 0);
        item.tags = newTags;
        item.pos = isPosEditMode ? editPosTextarea.value.trim() : modalContent.innerText.trim();

        // 替换图片逻辑
        if (replaceNewFile !== null) {
            try {
                await fetch("/delete-img", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ imgPath: oldModalImgPath })
                });
                const fd = new FormData();
                fd.append("img", replaceNewFile);
                const res = await fetch(UPLOAD_API, {
                    method: "POST",
                    body: fd
                });
                const json = await res.json();
                if (json.code !== 200) throw new Error(json.msg);
                item.imgPath = json.path;
                modalImg.src = item.imgPath;
            } catch (err) {
                toast("替换图片失败：" + err.message);
                return;
            }
        }

        await updateTagPool(newTags);
        await syncLibraryToDisk();
        renderGallery();
        modal.style.display = "none";
        currentViewId = null;
        toast("修改已保存至本地磁盘！");
    };
    closeModalBtn.onclick = (e) => {
        e.stopPropagation();
        modal.style.display = "none";
        currentViewId = null;
        replaceNewFile = null;
        replaceImgInput.value = "";
        replaceImgPreviewWrap.style.display = "none";
    };
    modal.onclick = (e) => {
        if (e.target === modal) {
            modal.style.display = "none";
            currentViewId = null;
            replaceNewFile = null;
            replaceImgInput.value = "";
            replaceImgPreviewWrap.style.display = "none";
        }
    };
    btnExport.onclick = async () => {
        try {
            const res = await fetch("/export-db", { method: "POST" });
            const ret = await res.json();
            if (ret.code === 200) {
                const tip = document.createElement("div");
                tip.style = "position:fixed;top:20px;left:50%;transform:translateX(-50%);background:#227744;color:#fff;padding:12px 24px;border-radius:6px;z-index:9999;max-width:90%;text-align:center;";
                tip.innerText = ret.msg;
                document.body.appendChild(tip);
                setTimeout(() => tip.remove(), 4000);
            } else {
                toast("备份失败：" + ret.msg);
            }
        } catch (err) {
            toast("请求备份接口异常：" + err.message);
        }
    };
    btnImport.onclick = () => importFile.click();
    importFile.onchange = async () => {
        const f = importFile.files[0];
        if (!f) return;
        const text = await f.text();
        try {
            const data = JSON.parse(text);
            if (!Array.isArray(data)) throw new Error("文件格式错误，必须是图库导出的数组JSON");
            data.forEach(it => {
                if (it.id === undefined) it.id = Date.now().toString() + Math.random().toString(36);
                if (!Array.isArray(it.tags)) it.tags = [];
                if (typeof it.nsfw !== "boolean") it.nsfw = false;
                if (typeof it.pos !== "string") it.pos = "";
                if (it.copyCount === undefined || typeof it.copyCount !== "number") it.copyCount = 0;
            });
            const isMerge = importMergeMode.checked;
            let tipMsg = "";
            if (isMerge) {
                const existIdSet = new Set(library.map(item => item.id));
                const uniqueNewList = data.filter(item => !existIdSet.has(item.id));
                library = [...library, ...uniqueNewList];
                tipMsg = `合并导入完成，共新增 ${uniqueNewList.length} 条不重复记录（已写入磁盘）`;
            } else {
                library = [...data];
                tipMsg = "覆盖导入完成，原有所有图库记录已替换（已写入磁盘）";
            }
            batchSelectIds = [];
            updateBatchTip();
            data.forEach(it => updateTagPool(it.tags || []));
            await syncLibraryToDisk();
            renderGallery();
            alert(tipMsg);
        } catch (err) {
            toast("导入失败：" + err.message);
        }
        importFile.value = "";
    };
    btnClearAllData.onclick = () => clearConfirmModal.style.display = "flex";
    cancelClearData.onclick = () => clearConfirmModal.style.display = "none";
    clearConfirmModal.onclick = (e) => {
        if (e.target === clearConfirmModal) clearConfirmModal.style.display = "none";
    };
    confirmClearData.onclick = async () => {
        try {
            const res = await fetch("/clear-all-img", { method: "POST" });
            const ret = await res.json();
            if (ret.code !== 200) throw new Error(ret.msg || "清除图片失败");
            library = [];
            tagPool = [];
            batchSelectIds = [];
            await syncLibraryToDisk();
            await syncTagPoolToDisk();
            updateBatchTip();
            renderTagHistory(); renderTagFilter(); renderGallery();
            clearConfirmModal.style.display = "none";
            const tip = document.createElement("div");
            tip.style = "position:fixed;top:20px;left:50%;transform:translateX(-50%);background:#227744;color:#fff;padding:10px 20px;border-radius:6px;z-index:9999;";
            tip.innerText = "全部数据清空成功，磁盘数据库已重置";
            document.body.appendChild(tip);
            setTimeout(() => tip.remove(), 2500);
        } catch (err) {
            const tip = document.createElement("div");
            tip.style = "position:fixed;top:20px;left:50%;transform:translateX(-50%);background:#992222;color:#fff;padding:10px 20px;border-radius:6px;z-index:9999;";
            tip.innerText = "清空失败：" + err.message;
            document.body.appendChild(tip);
            setTimeout(() => tip.remove(), 3000);
        }
    };
    function escapeHtml(str) {
        if (!str) return "";
        return str.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
    }
    searchInput.oninput = renderGallery;
    await loadDiskDatabase();
    renderTagHistory();
    renderTagFilter();
    renderGallery();
});
