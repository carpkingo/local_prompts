@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ======================本地图片提示词库启动器======================
echo 1. 检测Python环境...
python --version >nul 2>&1
if errorlevel 1 (
    echo 错误：未找到Python，请先安装Python并配置环境变量！
    pause
    exit
)
echo 2. 自动安装依赖flask...
pip install flask -i https://pypi.tuna.tsinghua.edu.cn/simple
echo 3. 启动服务 http://127.0.0.1:8000
start "" http://127.0.0.1:8000
python server.py
echo 服务已关闭，按任意键退出
pause